import dao.DbConnection;

import javax.crypto.*;
import java.io.UnsupportedEncodingException;
import java.rmi.*;
import java.rmi.server.*;
import java.security.InvalidKeyException;
import java.security.Key;
import java.security.NoSuchAlgorithmException;
import java.sql.*;
import java.util.List;

public class User extends UnicastRemoteObject implements ChatInterface {
 
	private String nom;
	private String password;
	public ChatInterface client = null;


	public User(String nom, String password) throws RemoteException {
		this.nom = nom;
		this.password = password;
	}
	public String getNom() throws RemoteException {
		return this.nom;
	}

	public void setNom(String nom) throws RemoteException{
		this.nom = nom;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public void setClient(ChatInterface c){
		client = c;
	}
 
	public ChatInterface getClient(){
		return client;
	}

	public String crypter(String message) {
		String crypte = "";
		for (int i = 0; i < message.length(); i++) {
			int c = message.charAt(i) ^ 56;
			crypte = crypte + (char) c;
		}
		return crypte;
	}

	public  String decrypter(String message) {
		String aCrypter = "";
		for (int i = 0; i < message.length(); i++) {
			int c = message.charAt(i) ^ 56;
			aCrypter = aCrypter + (char) c;
		}
		return aCrypter;
	}


	@Override
	public boolean insererMessage(String nom, String message) throws RemoteException {
		Connection conn  = DbConnection.getConnection();
		PreparedStatement state = null;
		if(conn != null){
			try {
				String query = "INSERT INTO chat(nom,message) VALUES(?,?)";
				state = conn.prepareStatement(query);
				state.setString(1, nom);
				state.setString(2, crypter(message));
				return state.executeUpdate() >= 1;
			}catch (SQLException ex){
				ex.printStackTrace();
			} finally {
				try {
					conn.close();
				}catch (Exception ex){
					ex.printStackTrace();
				}
			}
		}else {
			System.out.println("Connection non établie !");
		}
		return false;
	}

	@Override
	public void historique() throws RemoteException {
		Connection conn = DbConnection.getConnection();
		PreparedStatement state = null;
		ResultSet resultSet = null;
		String nom = null;
		String message = null;
		if(conn != null){
			try {
				String query = "SELECT nom, message FROM chat";
				state = conn.prepareStatement(query);
				resultSet = state.executeQuery();
				while (resultSet.next()){
					nom = resultSet.getString("nom");
					message = decrypter(resultSet.getString("message"));
					System.out.println("["+ nom +"] " + message);
				}
			}catch (SQLException ex){
				ex.printStackTrace();
			} finally {
				try {
					conn.close();
				}catch (Exception ex){
					ex.printStackTrace();
				}
			}
		}else {
			System.out.println("Connection non établie !");
		}
	}

	@Override
	public String seconnecter() throws RemoteException {
		Connection connection = DbConnection.getConnection();
		PreparedStatement state = null;
		ResultSet resultSet = null;
		String nom = null;
		if (connection != null){
			try{
				try {
					String query = "SELECT nom FROM user WHERE nom = ? AND password = ? ";
					state = connection.prepareStatement(query);
					state.setString(1, this.getNom());
					state.setString(2, this.getPassword());
					resultSet = state.executeQuery();
					if(resultSet.next()){
						nom = resultSet.getString("nom");
					}
				}catch (SQLException ex){
					ex.printStackTrace();
				}finally {
					connection.close();
				}

			}catch (SQLException ex){
				ex.printStackTrace();
			}
		}
		return nom;
	}



//	public void send(String s) throws RemoteException{
//		System.out.println("Historique\n**********");
//		historique();
//		System.out.println("**************\n Message recu \n**************");
//		System.out.println(s);
//	}

	@Override
	public void send(String message) throws RemoteException{

		System.out.println("**************\n Message recu \n**************");
		System.out.println(message);
	}
}