package dao;

import java.sql.Connection;
import java.sql.DriverManager;

public class DbConnection {
    public static Connection getConnection(){
        String url = "jdbc:sqlite:chatRMI.db";
        Connection conn = null;

        try {
            conn = DriverManager.getConnection(url);
        }catch (Exception ex){
            ex.printStackTrace();
        }

        return conn;
    }
}
