import java.rmi.*;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.rmi.server.*;
import java.util.*;
 
public class ChatServer {
public static void main (String[] argv) {
    try {
	    	while (true){
				Scanner s = new Scanner(System.in);
				System.out.println("Entrez votre nom:");
				String name=s.nextLine().trim();
				System.out.println("Entrez votre password:");
				String password = s.nextLine().trim();


				User server = new User(name,password);
				if (server.seconnecter() != null){
					Registry annuaire = LocateRegistry.createRegistry(1098);

					//
					System.setProperty("java.rmi.server.hostname", "192.168.43.1");

					// l'annuaire s'appelera: Chat
					annuaire.rebind("Chat", server);
					Naming.rebind("rmi://localhost:1098/Chat", server);

					System.out.println("Le chat est pret:");

					while(true){
						System.out.println("Entrer un message: ");
						String msg = s.nextLine().trim();
						if (msg.equals("historique")){
							System.out.println("Historique\n**********");
							server.historique();
						}else {
							if (server.getClient() != null){
								ChatInterface client = server.getClient();
								if (client.insererMessage(server.getNom(), msg))
									msg = "["+server.getNom()+"] "+ msg;
								client.send(msg);

							}
						}



					}
				}else {
					System.out.println("Vous n'etes pas inscrit");
				}
			}
//			Registry annuaire = LocateRegistry.createRegistry(1098);
//
//            // annuaire s'appelera: mailClient
//            annuaire.rebind("Chat", server);
//	    	Naming.rebind("rmi://localhost:1098/Chat", server);
//
//	    	System.out.println("Le chat est pret:");
//
//	    	while(true){
//	    		String msg = s.nextLine().trim();
//	    		if (server.getClient() != null){
//	    			ChatInterface client = server.getClient();
//	    			msg = "["+server.getNom()+"] "+msg;
//	    			client.send(msg);
//	    		}
//	    	}

    	}catch (Exception e) {
    		e.printStackTrace();
    	}
	}
}