import java.rmi.*;
import java.rmi.server.*;
import java.util.*;
 
public class ChatClient {
	public static void main (String[] argv) {
	    try {


				while (true){
					Scanner s = new Scanner(System.in);
					System.out.println("Entrez votre nom: ");
					String name = s.nextLine().trim();
					System.out.println("Entrez votre password:");
					String password = s.nextLine().trim();
					ChatInterface client = new User(name, password);
					if (client.seconnecter() != null){
						ChatInterface server = (ChatInterface)Naming.lookup("rmi://localhost:1098/Chat");
						String msg = "["+client.getNom()+"] s'est connecte";
						server.send(msg);
						System.out.println("Le CHAT est pret:");
						server.setClient(client);

						while(true){
							System.out.println("Entrer un message: ");
							msg = s.nextLine().trim();
							if (msg.equals("historique")){
								System.out.println("Historique\n**********");
								client.historique();
							}else {
								if (server.insererMessage(client.getNom(),msg))
									msg = "["+client.getNom()+"] "+ msg;
								server.send(msg);
							}
						}
					}else{
						System.out.println("Vous n'etes pas inscrit.");
					}
				}


	    	}catch (Exception e) {
	    		e.printStackTrace();
	    	}
		}
}