
import java.rmi.*;


public interface ChatInterface extends Remote{
	public String getNom() throws RemoteException;
	public void send(String msg) throws RemoteException;
	public void setClient(ChatInterface c) throws RemoteException;
	public ChatInterface getClient() throws RemoteException;
	public boolean insererMessage(String nom, String message) throws RemoteException;
	public String seconnecter() throws RemoteException;
	public String crypter(String message) throws RemoteException;
	public String decrypter(String message) throws RemoteException;
	public void historique() throws RemoteException;
}